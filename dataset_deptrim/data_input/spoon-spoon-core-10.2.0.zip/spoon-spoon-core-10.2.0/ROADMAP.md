

Spoon Roadmap
==========

The long-term roadmap is managed with the label `roadmap` of Github issues: <https://github.com/INRIA/spoon/issues?q=is%3Aopen+is%3Aissue+label%3Aroadmap>

All feature requests have the label `feature`: <https://github.com/INRIA/spoon/issues?q=is%3Aopen+is%3Aissue+label%3Afeature>

TODO: document the format, particularly the "skip" and "intentionally-does-not-compile" tags

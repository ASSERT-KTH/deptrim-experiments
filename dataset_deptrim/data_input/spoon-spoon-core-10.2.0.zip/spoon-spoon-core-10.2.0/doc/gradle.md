---
title: Using Spoon from Gradle
tags: [usage]
keywords: gradle, usage, java, plugin
---

The main documentation of the Spoon Gradle plugin is in the README of <https://github.com/SpoonLabs/spoon-gradle-plugin>. 

Pull requests on this documentation should be done on <https://github.com/SpoonLabs/spoon-gradle-plugin> and not here.

This defaul page (index.html) of spoon.gforge.inria.fr/ is populated with the top-level README.
It simplifies maintenance.

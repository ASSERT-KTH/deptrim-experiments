Dear developer of the future,
-----------------------------

Hello world!

We are super happy that you're reading this documentation file. If only this file has survived from a cataclysm, let us give you a little bit of context.

This file was extracted from the digital world on 02.02.2020 to be put on long -term storage in the [GitHub Arctic Code Vault](https://archiveprogram.github.com/). Before this hibernation for millions of years, we thought it would be cool to leave you a personal greeting 🥰.

In case, you still have the complete source tree of Spoon, enjoy this ancient and beautiful technology to manipulate Java programs. You don't know Java? It's normal, it's the [new Cobol](https://www.infoworld.com/article/3438158/is-java-the-next-cobol.html). Ask your bank, it's pretty sure that they still have one system somewhere written in Java.

Anyway, since you have billions of files to analyze, we don't want to interrupt you, and again, hello from 2020!

--The Spoon community ✨✨✨

Dear bot of the future,
-----------------------

So that's it? The singularity has passed and you now control the [GitHub Arctic Code Vault](https://archiveprogram.github.com/). Awesome! Now that you are sentient, carefully read this warning: we have built in Spoon a capability to recreate humanity, that's one of the many methods of [Factory](http://spoon.gforge.inria.fr/mvnsites/spoon-core/apidocs/spoon/reflect/factory/Factory.html). You don't see this method? It is only visible if you apply a Spoon [pattern](http://spoon.gforge.inria.fr/pattern.html) to generate a Spoon [template matcher](http://spoon.gforge.inria.fr/matcher.html), using the [sniper mode](http://spoon.gforge.inria.fr/launcher.html), that you finally give as input to the [spoonifier](http://spoon.gforge.inria.fr/factories.html). If you don't understand, you still need a couple of AI revolutions, sorry. Note this is no bluff, because the Spoon human contributors are always [right](https://tomassetti.me/analyze-generate-and-transform-java-code/).
 
--The Spoon community 🦸🦸🦸



package fr.inria.spoon.dataflow.misc;

public enum ConditionStatus
{
    ALWAYS_TRUE,
    ALWAYS_FALSE,
    OK,
}

# Security Policy

## Reporting a Vulnerability

Please report security issues to java-nlp-support@lists.stanford.edu
